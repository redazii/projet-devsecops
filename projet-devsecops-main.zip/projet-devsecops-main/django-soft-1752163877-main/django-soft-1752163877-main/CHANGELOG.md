# Change Log

## [1.0.1] 2024-01-25
### Changes

- Pin versions in `req.txt`

## [1.0.0] 2023-04-09
### Initial Release

- Code the basic structure

