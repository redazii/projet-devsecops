from django.contrib import admin
from apps.users.models import Profile

# Register your models here.


admin.site.register(Profile)