## Sentry

> Intro: What we offer

- Sentry for capturing errors

> How to use it 

- Create a `.env` file in the root directory and add the following credentials
```bash
DSN_KEY=
```

> Codebase: related app, model, template, js 

N/A
